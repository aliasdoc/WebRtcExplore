// TODO(pthatcher): Delete this file.  Pulse won't work without it for
// some reason.
