//
//  ios_demoTests.m
//  ios-demoTests
//
//  Created by Nigel Brooke on 2014-08-29.
//  Copyright (c) 2014 OTalk. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ios_demoTests : XCTestCase

@end

@implementation ios_demoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
