//
//  ViewController.h
//  Copyright (c) 2014 &yet, LLC and otalk contributors
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
