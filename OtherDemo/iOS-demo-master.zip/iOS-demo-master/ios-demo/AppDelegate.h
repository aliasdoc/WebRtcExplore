//
//  AppDelegate.h
//  Copyright (c) 2014 &yet, LLC and otalk contributors
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
