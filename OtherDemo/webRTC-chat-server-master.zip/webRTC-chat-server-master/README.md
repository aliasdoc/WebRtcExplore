# webRTC chat server #

This is an experiment to setup a java server using web sockets capable to setting up P2P text conversations using webRTC.

An iOS client can be found at https://github.com/skorulis/webRTC-chat-iOS
