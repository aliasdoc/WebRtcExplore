# webRTC chat #

This is an experiment to connect devices together randomly using webRTC to facilitate text chat. This works in conjunction with https://github.com/skorulis/webRTC-chat-server.


