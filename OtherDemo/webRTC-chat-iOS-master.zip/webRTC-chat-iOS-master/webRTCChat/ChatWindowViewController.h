//  Created by Alexander Skorulis on 13/03/2015.
//  Copyright (c) 2015 com.skorulis. All rights reserved.

@import UIKit;
#import "RTCService.h"

@interface ChatWindowViewController : UIViewController

- (instancetype) initWithService:(RTCService*)service;

@end
