//
//  PHErrors.m
//  PerchRTC
//
//  Created by Sam Symons on 2014-12-29.
//  Copyright (c) 2014 Perch Communications. All rights reserved.
//

NSString *const PHErrorDomain = @"co.perch.perch-rtc";

NSInteger const PHErrorCodeFullRoom = 101;
