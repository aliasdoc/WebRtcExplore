//
//  PHErrors.h
//  PerchRTC
//
//  Created by Sam Symons on 2014-12-29.
//  Copyright (c) 2014 Perch Communications. All rights reserved.
//

extern NSString *const PHErrorDomain;

extern NSInteger const PHErrorCodeFullRoom;
