# webRTC local chat #

This is a basic experiment with webRTC to be able to get full duplex communication inside a single application. It ignores the complexities of dealing with a server for routing SDP and ICE messages.
