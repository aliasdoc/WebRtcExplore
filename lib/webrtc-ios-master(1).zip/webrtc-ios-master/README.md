# webrtc-ios
WebRTC static libraries (armv7, arm64, i386) and header files packaged as a cocoa pod.


To enable this library add next line to Podfile
```
pod 'WebRTC', :podspec => 'https://raw.githubusercontent.com/dmitryrybakov/webrtc-ios/master/WebRTC.podspec'
````
