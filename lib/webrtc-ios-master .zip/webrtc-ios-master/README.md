webrtc-ios
==========

Static libraries (armv7, arm64, i386) and header files for WebRTC packaged as a cocoapod.

Add one line to your Podfile
```
pod 'WebRTC', :podspec => 'https://raw.githubusercontent.com/kapejod/webrtc-ios/masters/WebRTC.podspec'
````
